from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

# Clés d'activation valides (à modifier selon les besoins)
VALID_KEYS = ["quorabotai-keyact"]

@app.route("/", methods=["GET", "POST"])
def home():
    if request.method == "POST":
        key = request.form.get("activation_key")
        if key in VALID_KEYS:
            return redirect(url_for("dashboard"))
        else:
            return render_template("index.html", error=True)
    return render_template("index.html", error=False)

@app.route("/dashboard")
def dashboard():
    return render_template("dashboard.html")

if __name__ == "__main__":
    app.run(debug=True)